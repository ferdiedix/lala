# 999Dice Premium Script
An Dice mining script for [999DOGE]( https://www.999doge.com)

## Get Started

### Ubuntu
```
sudo apt update
```
```
sudo apt upgrade
```
```
sudo apt install python python-pip curl -y
```
```
pip3 install colorama
```
```
pip3 install requests
```
```
pip3 install bs4
```
```
git clone https://github.com/klvinnn/jek
```
```
cd 999
```
```
python3.7 999.py
```
### Termux
```
pkg update
```
```
pkg upgrade
```
```
pkg install git python python-pip curl -y
```
```
pip3 install colorama
```
```
pip3 install requests
```
```
pip3 install bs4
```
```
git clone https://github.com/klvinnn/jek
```
```
cd 999
```
```
python3.7 999.py
```
## Configuration
```
config.json
```
```
     "Username": "xxx",
     "Password": "xxx"
```
```
"Name Bet Set": "Happy JP",
     "Base Bet": "0.01",
     "Max Bet": "OFF",
     "Chance": "70",
     "Random Chance": {
          "Toggle": "ON",
          "Min": "5",
          "Max": "50"
        },
     "Bet": {
          "Bet": "Low",
          "Hi / Low": {
              "Toggle": "ON",
              "If Lose": "2",
              "If Win": "5"
            }
	        },
     "If Win": "1",
     "If Lose": "1.959",
     "Reset If Win": "0",
     "Reset If Profit": "0.00000001",
     "Interval": "1"
     },{
```
## Contact
[Telegram]( https://t.me/klvinnn)
[Telegram Group]( https://t.me/duniajake)
[Email]( mailto:kelvinwijaya131@gmail.com)

Donations for continued support of this script are welcomed at:

* BTC 17H4tAzcfiP8JEmYQ2BQ4gQfVfTmNjpcb8
* DOGE DRxZjD3PrffoRi1FfsjxqahzrguziTeC6T 
* LTC LRYtXgGVD38tFHK8VRQ18RMJTvUkSKVhgw
